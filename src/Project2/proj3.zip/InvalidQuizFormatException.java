package Project2;

public class InvalidQuizFormatException extends Exception {
    public InvalidQuizFormatException(String errorMessage) {
        super(errorMessage);
    }
}
